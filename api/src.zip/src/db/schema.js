const { sqliteTable, integer, text, real } = require("drizzle-orm/sqlite-core");

// Use snake_case for DB columns; Drizzle will map camelCase JS keys automatically
const cars = sqliteTable("cars", {
	id: integer("id").primaryKey({ autoIncrement: true }),
	make: text("make").notNull(),
	model: text("model").notNull(),
	year: integer("year").notNull(),
	weeklyRate: real("weekly_rate").notNull(),
	available: integer("available").default(1),
	licensePlate: text("license_plate").unique(),
	imageUrl: text("image_url"),
	createdAt: text("created_at").default("CURRENT_TIMESTAMP"),
	updatedAt: text("updated_at").default("CURRENT_TIMESTAMP"),
});

module.exports = { cars };

const db = require("./index");

const cars = [
	{ make: "Nissan", model: "Tiida", year: 2011, weeklyRate: 180, available: 1, licensePlate: "ABC-123", imageUrl: "https://picsum.photos/seed/nissan-tiida/400/300" },
	{ make: "Toyota", model: "Yaris", year: 2012, weeklyRate: 170, available: 1, licensePlate: "DEF-456", imageUrl: "https://picsum.photos/seed/toyota-yaris/400/300" },
	{ make: "Hyundai", model: "Accent", year: 2013, weeklyRate: 165, available: 1, licensePlate: "GHI-789", imageUrl: "https://picsum.photos/seed/hyundai-accent/400/300" },
	{ make: "Suzuki", model: "Swift", year: 2014, weeklyRate: 175, available: 1, licensePlate: "JKL-012", imageUrl: "https://picsum.photos/seed/suzuki-swift/400/300" },
	{ make: "Mitsubishi", model: "Mirage", year: 2015, weeklyRate: 185, available: 1, licensePlate: "MNO-345", imageUrl: "https://picsum.photos/seed/mitsubishi-mirage/400/300" },
	{ make: "Kia", model: "Rio", year: 2013, weeklyRate: 160, available: 1, licensePlate: "PQR-678", imageUrl: "https://picsum.photos/seed/kia-rio/400/300" },
];

// Create table and insert cars
db.serialize(() => {
	db.run(`
    CREATE TABLE IF NOT EXISTS cars (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      make TEXT,
      model TEXT,
      year INTEGER,
      weeklyRate INTEGER,
      available INTEGER DEFAULT 1,
      licensePlate TEXT UNIQUE,
      imageUrl TEXT
    )
  `);

	const stmt = db.prepare(`
    INSERT OR IGNORE INTO cars 
    (make, model, year, weeklyRate, available, licensePlate, imageUrl) 
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);

	cars.forEach(car => {
		stmt.run(car.make, car.model, car.year, car.weeklyRate, car.available, car.licensePlate, car.imageUrl);
	});

	stmt.finalize(() => {
		console.log("✅ Seeded cars successfully!");
		db.close();
	});
});
